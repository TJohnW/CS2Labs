
public interface Expression {

	Integer evaluate();

	String emit();

}
